#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from printer_system.srv import PrintJob
from std_msgs.msg import String
import time
from collections import deque

class PrinterNode(Node):
    def __init__(self):
        super().__init__('printer_server')
        self.job_queue = deque()
        self.publisher_ = self.create_publisher(String, '/print_status', 10)
        self.srv = self.create_service(PrintJob, '/print_job', self.handle_print_job)
        self.get_logger().info('Printer Server is ready.')
        self.timer = self.create_timer(1.0, self.process_queue)

    def handle_print_job(self, request, response):
        doc = request.document_name
        self.job_queue.append(doc)
        status = f"Job Queued: {doc}"
        self.publish_status(status)
        self.get_logger().info(status)
        response.accepted = True
        return response

    def process_queue(self):
        if self.job_queue:
            current_job = self.job_queue.popleft()
            self.publish_status(f"Started printing: {current_job}")
            self.get_logger().info(f"Started printing: {current_job}")
            time.sleep(3)  # Simulated printing delay
            self.publish_status(f"Completed printing: {current_job}")
            self.get_logger().info(f"Completed printing: {current_job}")

    def publish_status(self, message):
        msg = String()
        msg.data = message
        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = PrinterNode()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
