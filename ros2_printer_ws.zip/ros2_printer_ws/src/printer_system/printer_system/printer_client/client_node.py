#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from printer_system.srv import PrintJob
from std_msgs.msg import String

class PrinterClient(Node):
    def __init__(self):
        super().__init__('printer_client')
        self.cli = self.create_client(PrintJob, '/print_job')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for printer server...')
        self.req = PrintJob.Request()
        self.subscription = self.create_subscription(
            String,
            '/print_status',
            self.status_callback,
            10
        )
        self.subscription  # prevent unused variable warning

        # Example request - you can modify this to take input
        self.send_request("demo_document.pdf")

    def send_request(self, document_name):
        self.req.document_name = document_name
        self.future = self.cli.call_async(self.req)

    def status_callback(self, msg):
        self.get_logger().info(f"[Status Update] {msg.data}")

def main(args=None):
    rclpy.init(args=args)
    client = PrinterClient()
    rclpy.spin(client)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
