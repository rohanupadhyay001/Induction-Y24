from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='printer_system',
            executable='printer_node',
            name='printer_server'
        ),
        Node(
            package='printer_system',
            executable='client_node',
            name='printer_client'
        )
    ])
