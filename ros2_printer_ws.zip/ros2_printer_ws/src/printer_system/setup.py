from setuptools import setup
import os
from glob import glob

package_name = 'printer_system'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
         ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # Install launch file
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='your_name',
    maintainer_email='your_email@example.com',
    description='A simple printer queue system using ROS 2 services',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'printer_node = printer_system.printer_server.printer_node:main',
            'client_node = printer_system.printer_client.client_node:main',
        ],
    },
)

